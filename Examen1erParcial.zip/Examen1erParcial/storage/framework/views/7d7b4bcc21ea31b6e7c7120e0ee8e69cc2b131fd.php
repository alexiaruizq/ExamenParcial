<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Funcion</title>
</head>
<body>
    <h1>Crear Funcion</h1>
    <a href="<?php echo e(route('funciones.index')); ?>"> Regresar </a>
    <form method="post" action="<?php echo e(route('funciones.store')); ?>">
        <?php echo csrf_field(); ?>
        <label>Pelicula</label>
        <input type ="text" name="pelicula">
        <br>
        <label>Fecha</label>
        <textarea type ="text" name="fecha" rows="6"></textarea>
        <br>
        <label>Hora</label>
        <input type ="text" name="hora">
        <br>

        <button type="submit">Guardar</button>
    </form>

</body>
</html><?php /**PATH C:\Users\fatim\Downloads\ExamenGraficos-main (1)\ExamenGraficos-main\Examen1erParcial\Examen1erParcial\resources\views/funciones/create.blade.php ENDPATH**/ ?>